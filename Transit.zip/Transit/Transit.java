import java.util.ArrayList;

/**
 * This class contains methods which perform various operations on a layered linked
 * list to simulate transit
 * 
 * @author Julianne D'Avirro Humphrey
 * @author Ishaan Ivaturi
 * @author Prince Rawal
 */
public class Transit {
	/**
	 * Makes a layered linked list representing the given arrays of train stations, bus
	 * stops, and walking locations. Each layer begins with a location of 0, even though
	 * the arrays don't contain the value 0.
	 * 
	 * @param trainStations Int array listing all the train stations
	 * @param busStops Int array listing all the bus stops
	 * @param locations Int array listing all the walking locations (always increments by 1)
	 * @return The zero node in the train layer of the final layered linked list
	 */
	public static TNode makeList(int[] trainStations, int[] busStops, int[] locations) {
		// check that if looking for items don't use ptr=ptr.next need ptr.item=ptr.next.item
		// takes in 3 arrays of the stops for train, bus, and walk
		// need to make a zero node for each layer
		//	nodes in train layer must have .down to bus layer and same for bus to walk
		
		TNode train= new TNode();		// train null zero node
		TNode bus= new TNode(); 		// bus null zero node
		TNode walk= new TNode(); 		// walk null zero node
		TNode ptr= new TNode(); 		// makes a pointer to index with
		

		// index through each array of stations/stops/locations

		ptr=train; //holds train zero node
		int m;		//for indexing array
		for(int i=0; i<trainStations.length;i++){		//for each ele in stations 
			m=trainStations[i];		//extracts "current" element from stations
			ptr.next= new TNode(m);	//next node= location m
			ptr=ptr.next; // puts pointer on next node
		}	//train list is complete 

		ptr=bus;	//holds bus zero
		int n;		//for indexing array
		for(int i=0; i<busStops.length;i++){		//for each ele in stops 
			n=busStops[i];		//extracts "current" element from stops
			ptr.next= new TNode(n);	//next node= location n
			ptr=ptr.next; // puts pointer on next node
		}	// bus list is complete

		ptr=walk;	//holds walk zero
		int o=0;		//for indexing array
		for(int i=0; i<locations.length;i++){
			o=locations[i];			// extracts "current" ele from locations
			ptr.next= new TNode(o);		//next node= location o
			ptr=ptr.next; // puts pointer on next node
		}	// walk list in complete

			//zero nodes must be linked with .down, then the rest accordingly checking train[]==bus[] and bus[]==walk[]				
			//now each linked list should exist, separately. link downs accordingly checking where train==bus and bus==walk
				//zeros first
				train.down=bus;
				bus.down=walk;
		
			TNode topCheck= new TNode();			//makes node to look for == assigned top row
		TNode bottomCheck= new TNode();			//makes node to look for == at row below top
		TNode zeroHold= new TNode();			//holds zero node, 
		zeroHold=train;
		topCheck=zeroHold;
		bottomCheck=zeroHold.down;
		while(zeroHold.down!=null){	//while there are still rows (until after walk)
			topCheck=zeroHold;			
			bottomCheck=zeroHold.down;	//row below topcheck
			while(topCheck!=null){
				if(topCheck.location==bottomCheck.location){
					topCheck.down=bottomCheck;		//bottom is a down of top
					topCheck=topCheck.next;			// if a match is made, move to next top
				}
					
					bottomCheck=bottomCheck.next;		//if no match, check next bottom
			}
			zeroHold=zeroHold.down;		//top zero becomes next row, shifts row searchers down
		}

		return train; //return zero node of train layer
	}
	
	/**
	 * Modifies the given layered list to remove the given train station but NOT its associated
	 * bus stop or walking location. Do nothing if the train station doesn't exist
	 * 
	 * @param trainZero The zero node in the train layer of the given layered list
	 * @param station The location of the train station to remove
	 */
	public static void removeTrainStation(TNode trainZero, int station) {
		// use a pointer
		TNode ptr= new TNode();
		TNode editor= new TNode();		//holds the next edit
		ptr=trainZero;			//sets to train zero
		editor=trainZero;
		while(ptr!=null){		//!= null makes the loop end once it reaches the end of the train list
			while(ptr.location<station){
				if(ptr.next==null){
					break;
				}
				ptr=ptr.next; 		// since it doesn't ever remove 0 location, can set it to the first node. also lets it check next if == fails
				if(ptr.location == station){		//if the value held by the node ptr is at == station
					if(ptr.next==null){
						editor.next=null;
					} else{
						editor.next=ptr.next;		//sets the current.next to the node after the next.	
					}	
					break;
				}
				editor=editor.next;
			}
		break;
		}	
		
	}

	/**
	 * Modifies the given layered list to add a new bus stop at the specified location. Do nothing
	 * if there is no corresponding walking location.
	 * 
	 * @param trainZero The zero node in the train layer of the given layered list
	 * @param busStop The location of the bus stop to add
	 */
	public static void addBusStop(TNode trainZero, int busStop) {
		// given train, want to work in bus, so need train.down at train zero to get bus zero
		// note it's guaranteed to corresp. to walk node so will have to assign busxx.down
		TNode ptr= new TNode();
		TNode prevHold= new TNode();		//holds previous
		TNode busHold= new TNode(busStop);		//is the new node with location busStop
		TNode walkCount= new TNode();
		ptr=trainZero.down;		//points to bus' zero
		prevHold=ptr;
		walkCount=trainZero.down.down;	//gets to walk zero from train zero
		while(ptr!=null){		//ends when outside of bus list
			if(ptr.next==null){		//if ptr.next==nul it is edge case
				prevHold.next=busHold;
				break;
			}
			ptr=ptr.next;	//moves to next

			if(ptr.location>busStop){	
				//since we check 1 by 1 from the beginning, if the previous ndoe failed this and it passes now,
				//then the target will be just before this node
				busHold.next=ptr;		//fills second part of TNode, just need down now
				prevHold.next=busHold;		//enters new node
				break; //gets out of while loop
			}
			prevHold=prevHold.next;
			
		}	
		if(walkCount.next!=null){
			while(walkCount.location<=prevHold.location){			//stays == ptr.location
				walkCount=walkCount.next;
			}
		}
			walkCount=walkCount.next;
			busHold.down=walkCount;		//the down of the bus == walk at same location
			if(busHold.location!=walkCount.location){
				prevHold.next=null;
			}
	}
	
	/**
	 * Determines the optimal path to get to a given destination in the walking layer, and 
	 * collects all the nodes which are visited in this path into an arraylist. 
	 * 
	 * @param trainZero The zero node in the train layer of the given layered list
	 * @param destination An int representing the destination
	 * @return
	 */
	public static ArrayList<TNode> bestPath(TNode trainZero, int destination) {
		//can treat as if it is "sorted", can use < and > to check vals
		//add to array: train vals < target, train vals<= bus vals<=target, bus vals<=walk vals==target
		ArrayList<TNode> arrList= new ArrayList<TNode>();	//empty array w/ cap 10 but will automatically adjust
								//do I need ArrayList<Integer>();????
		TNode temp= new TNode();	//temp for holding info that gets sent to array
		TNode zeroDex= new TNode();		//holds the zero spot
		TNode indexer= new TNode();		//for going through the linked list
		indexer= trainZero;
		zeroDex=trainZero;
		while(zeroDex!=null){		//not below bottom row
			while(indexer!=null){	// staying in bounds of list
				if(indexer.location<=destination){
					temp=indexer;		//temp holds index's position
					arrList.add(temp);		//adds the current location to arrList
					indexer=indexer.next;			//moves indexer to next node
				} else{ // when it is greater than
					break;
				}

			}
			zeroDex=zeroDex.down;		//down check alsomoves down cuz if there is no lower level it stops the code
			indexer=temp.down;			//if the next location was too big, then go to previous and go down to lower level				
			
		}
		return arrList;		//return array list
	}

	/**
	 * Returns a deep copy of the given layered list, which contains exactly the same
	 * locations and connections, but every node is a NEW node.
	 * 
	 * @param trainZero The zero node in the train layer of the given layered list
	 * @return
	 */
	public static TNode duplicate(TNode trainZero) {
		// need to make a new linked list to copy the info from trainzero's
		// set the new nodes' info = to the original's xx.location xx.next xx.down
		TNode deepHold= new TNode();	//holds zero of the deep
		TNode original= new TNode();	//for going through original
		TNode originalHold= new TNode();	//holds the zero of the row for origianl
		TNode pt= new TNode();		
		TNode next= new TNode();
		//Using holds and down check for case where this is used for more than 3 modes of transportation
		// it should work for where there is also scooter (or any other modes added, any # layer of list)

			originalHold=trainZero;
			original=originalHold;							
			TNode deepTrain= new TNode(original.location);	//holds deepTrain returning thing, trainzero info
			deepHold=deepTrain;
			pt=deepHold;
		//i'm going to have my new deeptrain thing, and a pointer newpt on teh new deeptrain thing the new deeptrain thing will change to train orign info w/ its down etc 
		//pointer newpt will change to new deeptrain.next and new.down and build through threre

		while(originalHold!=null){ 	//while there are existing rows in original
			original=originalHold;			//orignal indexes across, cuz hold indexes down
			pt=deepHold;
			while(original!=null){
			original=original.next;				//cuz zero node is always zero
			if(original==null){
				break;
			}
			next= new TNode(original.location);
			pt.next=next;
			pt=pt.next;
			}
			originalHold=originalHold.down;	//moves down a layer
			if(originalHold!=null){
			deepHold.down= new TNode();
			deepHold=deepHold.down;
			}
		}
	//	deepHold.down=null;		//clears last one

		//now need to connect downs
		//already have the zeros connected
		TNode topCheck= new TNode();			//makes node to look for == assigned top row
		TNode bottomCheck= new TNode();			//makes node to look for == at row below top
		TNode zeroHold= new TNode();			//holds zero node, 
		zeroHold=deepTrain;
		topCheck=zeroHold;
		bottomCheck=zeroHold.down;
		while(zeroHold.down!=null){	//while there are still rows (until after walk)
			topCheck=zeroHold;			
			bottomCheck=zeroHold.down;	//row below topcheck
			while(topCheck!=null){
				if(topCheck.location==bottomCheck.location){
					topCheck.down=bottomCheck;		//bottom is a down of top
					topCheck=topCheck.next;			// if a match is made, move to next top
				}
					
					bottomCheck=bottomCheck.next;		//if no match, check next bottom
			}
			zeroHold=zeroHold.down;		//top zero becomes next row, shifts row searchers down
		} 
	
		return deepTrain;
	}


	/**
	 * Modifies the given layered list to add a scooter layer in between the bus and
	 * walking layer.
	 * 
	 * @param trainZero The zero node in the train layer of the given layered list
	 * @param scooterStops An int array representing where the scooter stops are located
	 */
	public static void addScooter(TNode trainZero, int[] scooterStops) {
		//start by making scooter linked 1 layer 
		//scooter is below bus and above walking, so need to (re)assign bus downs to scooter
		//then assign scooter.down with walk  ... just like makeLIst
		
		TNode scooter= new TNode(); 		//scooter's zero
		TNode ptr= new TNode();			//pointer
		ptr=scooter;	//holds walk zero
		
		int p=0;		//for indexing array
		for(int i=0; i<scooterStops.length;i++){
			p=scooterStops[i];			// extracts "current" ele from scooterStops
			ptr.next= new TNode(p);		//next node= location p
			ptr=ptr.next; // puts pointer on next node
		}	// scooter list list in complete

		TNode bus= new TNode();		//brings this to label
		bus=trainZero.down;			//bus node now points to bus in linked list
		//now the down assigns
			//zero first
			scooter.down=bus.down;		//scooter takes walk as down, rn both bus&scooter.down =walk
			bus.down=scooter;		//bus zero .down= scooter  so bus.down=scooter, and scooter.down=walk
			
		TNode topCheck= new TNode();			//makes node to look for == assigned top row
		TNode bottomCheck= new TNode();			//makes node to look for == at row below top
		TNode zeroHold= new TNode();			//holds zero node, 
		zeroHold=bus;		//starting at bus now since train has no changes
		topCheck=zeroHold;

		while(zeroHold.down!=null){	//while there are still rows (until after walk)
			topCheck=zeroHold;			
			bottomCheck=topCheck.down;	//row below topcheck
			while(topCheck!=null){
				if(topCheck.location==bottomCheck.location){
					topCheck.down=bottomCheck;		//bottom is a down of top
					topCheck=topCheck.next;			// if a match is made, move to next top
				}
					
				bottomCheck=bottomCheck.next;		//if no match, check next bottom
			}
			zeroHold=zeroHold.down;		//top zero becomes next row, shifts row searchers down
		}





	}
}