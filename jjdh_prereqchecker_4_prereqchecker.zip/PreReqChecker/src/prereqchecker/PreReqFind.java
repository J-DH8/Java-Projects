package prereqchecker;
import java.util.*;

public class PreReqFind{
    private boolean valid;                  //for compares to another course
    //private ArrayList <Course> required;    //lists all required courses
    public  PreReqFind (){
        this.valid=true;
      //  this.required= new ArrayList <Course>();
    }

    //Finds a preReq
    public boolean PreFinding(ArrayList <Course> arr, Course hold, String target){  
                //need inputs of the arraylist of courses
        //the course we're looking at
        // the course we're looking for

        //if you(2) wanna be my prereq, i(1) can't be in your prereqs
        // 1 can't be prereq of 2
        ArrayList <Course> existCheck= hold.getPrereqs();   //gets the prereqs of looking at
        int ec=existCheck.size();
        if(ec>0){    //checks if there are prereqs
            for(int i=0;i<ec; i++){
                if(existCheck.get(i).getName().equals(target)){     //if target is direct prereq
                    this.valid=false;
                    break;
                }
                else{       //check that things prereqs for target
                    if(existCheck.get(i).getPrereqs().size()>0){       //if the current prereq has prereqs
                    PreFinding(arr, existCheck.get(i), target);      //recursively calls it
                    //calls it to find if it is an indirect prereq
                    }

                }

            }
        }       //if no prereqs exist, just return true cuz its not circular

    return valid;
    }


}
