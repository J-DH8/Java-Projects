package prereqchecker;

import java.util.*;


/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * NeedToTakeInputFile name is passed through the command line as args[1]
 * Read from NeedToTakeInputFile with the format:
 * 1. One line, containing a course ID
 * 2. c (int): Number of courses
 * 3. c lines, each with one course ID
 * 
 * Step 3:
 * NeedToTakeOutputFile name is passed through the command line as args[2]
 * Output to NeedToTakeOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */
public class NeedToTake {
    public static void main(String[] args) {

       if ( args.length < 3 ) {
            StdOut.println("Execute: java NeedToTake <adjacency list INput file> <need to take INput file> <need to take OUTput file>");
            return;
        }
        
        StdIn.setFile(args[0]);                             //adjlist input file
        String firstA= StdIn.readString();                  //first tells how many courses
        ArrayList<Course> courseList= new ArrayList<Course> ();     //courses that can be substituted for this
    
        int numOfCourses=Integer.parseInt(firstA);          //know it is an int
        String holder;
        for(int i=0; i<numOfCourses; i++){
            holder=  StdIn.readString();            //reads each courseID
            Course newCourse= new Course (holder);   //makes course 
            courseList.add(newCourse);                    //adds to the array list of courses
        }
        //here we have arraylist list of courses that stand alone, now need to make them point
        int listSize= courseList.size();
        String secondB= StdIn.readString();                  // tells how many prereq connections exist
        int numOfprereqs=Integer.parseInt(secondB);          //know it is an int
        Course holding= new Course("x");
        String nameCheck= "y";
        for (int j=0; j<(2*numOfprereqs); j++){     //multiply numofprereqs by 2 because [course][prereq]
            String pointer=StdIn.readString();      //first is the course name, second is its prereq
            j++;    //counts course read
            int k=0;
            //initalizing outsize loop saves space (?) 
            while(k<listSize){        //to go through the arraylist to find the course
                holding= courseList.get(k);  //gets the course
                nameCheck= holding.getName();
                if(pointer.equals(nameCheck)){      //if holding's name matches pointer's name found it
                   // have the right spot
                    Course reqCheck= new Course("x");     //to find the prereq in arrlist
                    String pointee=StdIn.readString();       //reads the prereq
                    int m=0; 
                    //find the prereq in adjList
                    while(m<listSize){        //to go through the arraylist to find the prereq
                        reqCheck= courseList.get(m);         //gets the current course   
                        nameCheck= reqCheck.getName();
                        if(pointee.equals(nameCheck)){      //if reqCheck name== pointee found the prereq
                            holding.addPrereq(reqCheck);    //adds the prepreq to the PreReq.arrlist of holding
                            break;                          //stop loop when found & inserted
                        }   
                        //else keep going
                        m++;    //check next element
                    }//endwhile
                }   //endif
               
                //nothing found keep going
                k++;    //check next element
           }
    
                //iterating counts prereq read
                //moves to get next info
           }
        //now we have an arrlist CourseList with all the courses & courses contain arrlists of prereqs
       
        
        StdIn.setFile(args[1]);         //sets to n2T input
        String target= StdIn.readString();      //reads the target class
        int d=Integer.parseInt(StdIn.readString());     //gets # of courses taken       
        ArrayList<Course> taken= new ArrayList<Course>();  
        String hello="x";
        Course insert= new Course("x");
        for(int q=0; q<d; q++){    //to read each course taken
            hello=StdIn.readString();       //gets name of class taken
            for(int z=0; z<courseList.size();z++){      //finds it as courseList
                if(courseList.get(z).getName().equals(hello)){
                    insert= courseList.get(z);
                    taken.add(insert);      // adds          
                }
            }
            
        }       //arraylist of things taken 
        //make full list of everything taken (find its prereqs)
        fullFind asdf= new fullFind();
        ArrayList<Course> allTaken= asdf.fullFinds(taken);       //takes in direct prereqs and recurses back to get the rest 
        
        //make full list of everything you need for target
        ArrayList<Course> targetList=new ArrayList<Course>();
        for(int r=0; r<courseList.size();r++){      //find target 
            if(courseList.get(r).getName().equals(target)){     //find the target course
                Course foundTarget= courseList.get(r);      //get target course
                ArrayList<Course> foundPrereqs= foundTarget.getPrereqs();       //have targets direct prereqs
                fullFind jkl= new fullFind();
                targetList= jkl.fullFinds(foundPrereqs);       //takes in direct prereqs and recurses back to get the rest 
                //targetlist should have all needed courses to get to target without repeats
            }

        }
        
        //now have alltaken with all the courses already taken
        //and target list which is all the courses needed for the target course
        int s=0;
        boolean removed=false;  //checks if something was removed
        while(s<targetList.size()){ // targetList
            removed=false;  //sets false for each new check in targetlist
            for(int t=0; t<allTaken.size();t++){    //through all taken
                if(targetList.get(s).getName().equals(allTaken.get(t).getName())){  //if match found
                    targetList.remove(s);
                    removed=true;
                    break;
                    //cuz things shift don't increment s
                }
            }
            if(removed==false){ //if no match (no remove)
                s++;
            }
        }
   
        StdOut.setFile(args[2]);         //sets output
        for(int v=0; v<targetList.size();v++){  //for each eligible
                StdOut.println(targetList.get(v).getName());             //prints a line before each is added

        }
        
        

    }
}
             