package prereqchecker;
import java.util.*;

public class Order{
    ArrayList<ArrayList<Course>> plan;            //holds eligible courses

    public  Order (){
        this.plan= new ArrayList<ArrayList<Course>>();
        for(int u=0; u<9;u++){
            ArrayList<Course> nEww=new ArrayList<Course>();
            this.plan.add(nEww);   ///makes empty arraylists for plan
        } //makes arraylist of arraylists with 9 things, shouldn't be longer than 8 sems 1 buffer
        
    }

    //Finds preReqs
    public ArrayList<ArrayList<Course>> findPlan(ArrayList <Course> direct, ArrayList <Course> targetList){ 
        //takes in targets prereqs array and targetList (no reapeats, no taken)
        if(direct.size()>0){        //if direct prereqs exist
            deep(direct, targetList);
            //has repeats, if it is in higher, keep higher
            
        }
        //

        boolean drop=true;
        for(int a=1;a<this.plan.size();a++){ //checks starting second level
            for(int b=0;b<this.plan.get(a).size();b++){  //each thing second level
                for(int c=0;c<this.plan.get(a).get(b).getPrereqs().size();c++){  // for each prereq of b
                    for(int d=0; d<this.plan.get(a-1).size();d++){   //look for prereq  in a-1
                        if (this.plan.get(a).get(b).getPrereqs().get(c).equals(this.plan.get(a-1).get(d))){ //if you find a prereq
                            drop=false;
                        }
                    }
                }
                if(drop==true){
                    this.plan.get(a-1).add(this.plan.get(a).get(b));  //move it down to a-1
                    this.plan.get(a).remove(b);  //remove it from a
                }

            }
        }//end shifts
        boolean up=false;
        for(int aa=0;aa<this.plan.size();aa++){
            for(int bb=0;bb<this.plan.get(aa).size();bb++){ //each thing in 
                for(int cc=bb+1; cc<this.plan.get(aa).size();cc++){ //across
                    Course first= plan.get(aa).get(bb);
                    Course second= plan.get(aa).get(cc);
                    ArrayList<Course> firList= first.getPrereqs();
                    //compare 
                    for(int dd=0; dd<firList.size();dd++){  //for each first prereq
                        if(firList.get(dd).getName().equals((second.getName()))){ //if first's prereq== second
                            up=true;
                            break;
                        }   

                    }

                }
            
                if(up==true){
                    this.plan.get(aa+1).add(this.plan.get(aa).get(bb));  //move it up to aa+1
                    this.plan.get(aa).remove(bb);  //remove it from aa
                    up=false;
                }
            }
        }

        for(int f=this.plan.size()-1;f>-1;f--){
            if(this.plan.get(f).size()==0){
                this.plan.remove(f);
            }
        }   //trim down
        return this.plan;
        

    }// end findplan




    public int deep(ArrayList <Course> direct, ArrayList <Course> targetList){ 
        int depth= 0;
        int ee=0;
        Course prePre= new Course("x");
        for(int s=0; s<direct.size();s++){        // loops through direct 
            depth=0;
            prePre= direct.get(s);         //current direct prereq
            if(prePre.getPrereqs().size()!=0){    //if it has prereqs
                depth++;   //increases depth & goes deeper
                ee= deep(prePre.getPrereqs(),targetList);   //recurse
                depth=ee+depth;
            }//recurses until a prereq is found without prereqs (a lowest level class is found)
            boolean duplicate=false;
            for(int i=0; i<targetList.size();i++){  //find it in target list
                if(prePre.getName().equals(targetList.get(i).getName())){   //if it is in target list
                    for(int j=0; j<this.plan.size();j++){   //each level in plan
                        for(int k=0; k<this.plan.get(j).size();k++){    //for each thing in each level
                            if(this.plan.get(j).get(k).getName().equals(prePre.getName())){   // if prePre is found in plan
                                duplicate=true; //found dupe
//                                depth=depth-(targetList.get(i).getPrereqs().size());
                            }
                            if(duplicate==true){
                                break;
                            }

                        }
                        if(duplicate==true){
                            break;
                        }
                    }
 
                    if(duplicate==true){
                        break;
                    }  

                    if(duplicate==false){
                        //if not a dupe, 
                        this.plan.get(depth).add(prePre);            
                    } 
                }
                 
            }
       
        }
        //depth=ee+depth;
        return depth;    
    }
}



 