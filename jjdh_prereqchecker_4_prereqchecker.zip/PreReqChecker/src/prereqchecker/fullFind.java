package prereqchecker;
import java.util.*;

public class fullFind{
    ArrayList<Course> targetList;   //arraylist of all needed courses no repeats

    public  fullFind (){
        this.targetList= new ArrayList<Course> ();
    }

    //Finds preReqs
    public ArrayList<Course> fullFinds(ArrayList <Course> direct){ 
                //need inputs of the arraylist of direct prereq
        //can hopefully recurse this 
        if(direct.size()>0){        //if direct prereqs exist
            for(int s=0; s<direct.size();s++){        // loops through direct
                Course prePre= direct.get(s);         //current direct prereq
                //check if it is in targetlist already
                Course inTarget= new Course("x");
                boolean duplicate=false;
                for(int u=0; u<this.targetList.size();u++){  //for each thing in targetlist
                    inTarget= this.targetList.get(u);  //gets current targetlist thing
                    if(inTarget.getName().equals(prePre.getName())){   // if the current namein target== direct prereq
                        duplicate=true; //found dupe
                        break;
                    }
                }   //after checking targetlist
                    if(duplicate==false){
                        //if not a dupe, add it targetlist
                        this.targetList.add(prePre);      
                    } 
                    //regardless of dupe, gotta check it's prereqs
                    fullFinds(prePre.getPrereqs()); //recurses calling it for the direct(s)       
            
            }  
    

        }
        


        return this.targetList;
        
        

      //full find is all "needed" courses for target,, all of targets prereqs
            

    }// end fullfinds


}





 