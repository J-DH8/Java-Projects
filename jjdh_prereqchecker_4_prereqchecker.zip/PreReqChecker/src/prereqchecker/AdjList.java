package prereqchecker;
import  java.util.*;
 
//   1   uncomment back in package
//   2   uncomment main if args
//   3   fix setfiles back to args[0,1,2]
//   4   last stdin.set(output) NEEDS to be STDOUT.set(output)


/** 
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * AdjListOutputFile name is passed through the command line as args[1]
 * Output to AdjListOutputFile with the format:
 * 1. c lines, each starting with a different course ID, then 
 *    listing all of that course's prerequisites (space separated)
 */
public class AdjList {
    public static void main(String[] args) {

        if ( args.length < 2 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.AdjList <adjacency list INput file> <adjacency list OUTput file>");
            return;
        }

	//take inputs
    StdIn.setFile(args[0]);                             //adjlist input file
    String firstA= StdIn.readString();                  //first tells how many courses
    ArrayList<Course> courseList= new ArrayList<Course> ();     //courses that can be substituted for this

    int numOfCourses=Integer.parseInt(firstA);          //know it is an int
    String holder;
    for(int i=0; i<numOfCourses; i++){
        holder=  StdIn.readString();            //reads each courseID
        Course newCourse= new Course (holder);   //makes course 
        courseList.add(newCourse);                    //adds to the array list of courses
    }
    //here we have arraylist list of courses that stand alone, now need to make them point
    int listSize= courseList.size();
    String secondB= StdIn.readString();                  // tells how many prereq connections exist
    int numOfprereqs=Integer.parseInt(secondB);          //know it is an int
    for (int j=0; j<(2*numOfprereqs); j++){     //multiply numofprereqs by 2 because [course][prereq]
        String pointer=StdIn.readString();      //first is the course name, second is its prereq
        j++;    //counts course read
        int k=0;
        Course holding= new Course("x");
        String nameCheck= "y";
        //initalizing outsize loop saves space (?) 
        while(k<listSize){        //to go through the arraylist to find the course
            holding= courseList.get(k);  //gets the course
            nameCheck= holding.getName();
            if(pointer.equals(nameCheck)){      //if holding's name matches pointer's name found it
               // have the right spot
                Course reqCheck= new Course("x");     //to find the prereq in arrlist
                String pointee=StdIn.readString();       //reads the prereq
                int m=0; 
                //find the prereq in adjList
                while(m<listSize){        //to go through the arraylist to find the prereq
                    reqCheck= courseList.get(m);         //gets the current course   
                    nameCheck= reqCheck.getName();
                    if(pointee.equals(nameCheck)){      //if reqCheck name== pointee found the prereq
                        holding.addPrereq(reqCheck);    //adds the prepreq to the PreReq.arrlist of holding
                        break;                          //stop loop when found & inserted
                    }   
                    //else keep going
                    m++;    //check next element
                }//endwhile
            }   //endif
           
            //nothing found keep going
            k++;    //check next element
       }

            //iterating counts prereq read
            //moves to get next info
       }          

        //once done, set tht output file & print to it
    StdOut.setFile(args[1]);     //adjlist output file
   
    for( int l=0; l< listSize;l++){     //goes through list of classes
        Course printing= courseList.get(l);
        StdOut.print(printing.getName());           //prints course name
        ArrayList <Course> printprereq= printing.getPrereqs();
        
        if(printprereq.size()!=0){      //if it has prereqs
            for(int n=0;n<printprereq.size();n++){
                StdOut.print(' '+ printprereq.get(n).getName());       //prints each prereq name
            }
        }
        StdOut.println();
    }
   
    }


}






