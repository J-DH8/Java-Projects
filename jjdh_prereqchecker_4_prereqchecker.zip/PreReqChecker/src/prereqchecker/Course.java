package prereqchecker;
import java.util.*;

public class Course{

private String name;                  //name of the course
private ArrayList <Course> prereq;           // prerequisites list
//haha doubly linked now (is that illegal??/)
    public  Course (String name){
        this.name= name;
        this.prereq= new ArrayList <Course>() ;           // prerequisites list
    }

    public void addPrereq (Course prereq){   //adds a prereq
        this.prereq.add(prereq);
    }

    public String getName(){
        return this.name;
    }

    public ArrayList<Course> getPrereqs(){
        return this.prereq;
    }

    

}