package huffman;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;

import javax.lang.model.util.ElementScanner6;

/**
 * This class contains methods which, when used together, perform the
 * entire Huffman Coding encoding and decoding process
 * @author Julianne D'Avirro Humphrey
 * @author Ishaan Ivaturi
 * @author Prince Rawal
 */
public class HuffmanCoding {
    /**
     * Writes a given string of 1's and 0's to the given file byte by byte
     * and NOT as characters of 1 and 0 which take up 8 bits each
     * 
     * @param filename The file to write to (doesn't need to exist yet)
     * @param bitString The string of 1's and 0's to write to the file in bits
     */
    public static void writeBitString(String filename, String bitString) {
        byte[] bytes = new byte[bitString.length() / 8 + 1];
        int bytesIndex = 0, byteIndex = 0, currentByte = 0;

        // Pad the string with initial zeroes and then a one in order to bring
        // its length to a multiple of 8. When reading, the 1 signifies the
        // end of padding.
        int padding = 8 - (bitString.length() % 8);
        String pad = "";
        for (int i = 0; i < padding-1; i++) pad = pad + "0";
        pad = pad + "1";
        bitString = pad + bitString;

        // For every bit, add it to the right spot in the corresponding byte,
        // and store bytes in the array when finished
        for (char c : bitString.toCharArray()) {
            if (c != '1' && c != '0') {
                System.out.println("Invalid characters in bitstring");
                System.exit(1);
            }

            if (c == '1') currentByte += 1 << (7-byteIndex);
            byteIndex++;
            
            if (byteIndex == 8) {
                bytes[bytesIndex] = (byte) currentByte;
                bytesIndex++;
                currentByte = 0;
                byteIndex = 0;
            }
        }
        
        // Write the array of bytes to the provided file
        try {
            FileOutputStream out = new FileOutputStream(filename);
            out.write(bytes);
            out.close();
        }
        catch(Exception e) {
            System.err.println("Error when writing to file!");
        }
    }
    
    /**
     * Reads a given file byte by byte, and returns a string of 1's and 0's
     * representing the bits in the file
     * 
     * @param filename The encoded file to read from
     * @return String of 1's and 0's representing the bits in the file
     */
    public static String readBitString(String filename) {
        String bitString = "";
        
        try {
            FileInputStream in = new FileInputStream(filename);
            File file = new File(filename);

            byte bytes[] = new byte[(int) file.length()];
            in.read(bytes);
            in.close();
            
            // For each byte read, convert it to a binary string of length 8 and add it
            // to the bit string
            for (byte b : bytes) {
                bitString = bitString + 
                String.format("%8s", Integer.toBinaryString(b & 0xFF)).replace(' ', '0');
            }

            // Detect the first 1 signifying the end of padding, then remove the first few
            // characters, including the 1
            for (int i = 0; i < 8; i++) {
                if (bitString.charAt(i) == '1') return bitString.substring(i+1);
            }
            
            return bitString.substring(8);
        }
        catch(Exception e) {
            System.out.println("Error while reading file!");
            return "";
        }
    }

    /**
     * Reads a given text file character by character, and returns an arraylist
     * of CharFreq objects with frequency > 0, sorted by frequency
     * 
     * @param filename The text file to read from
     * @return Arraylist of CharFreq objects, sorted by frequency
     */
    public static ArrayList<CharFreq> makeSortedList(String filename) {
        StdIn.setFile(filename);
        //need size of string
        String charNum=StdIn.readAll();
        int inputSize= charNum.length();
        ArrayList<CharFreq> sortedList= new ArrayList<CharFreq>();
        //base
        if(inputSize==0){
            return null;
        }
        StdIn.setFile(filename);        //since it read all before it needs to reset at the file top
        int[] ascii= new int [128]; //makes array for ascii to count how many instances

        while(StdIn.hasNextChar()){   //while there are more characters to read, while true
            char y=StdIn.readChar();     //read each char
            double g=(double) y;        //makes char into double
            if( g != 127.00){
            ascii[y]=ascii[y]+1;    //adds a count at the ascii value for that char
            }else{ //if 127
                ascii[y]=0;
            }
        }
        
        //now get that array info into charfreq info
        for(int i=0; i<128; i++){
            if(ascii[i]!=0){
                char z= (char) i;     //takes the value 0-127 of i and turns into char
                double j= ascii[i];     //takes the count 
                j= (j/inputSize);
                CharFreq adding= new CharFreq(z,j);         //makes into charfreq
                sortedList.add(adding);     //puts into array list
            }
        }
             //The Huffman Coding algorithm does not work when there is only 1 distinct character. 
        //For this specific case, you must add a different character with probOcc 0 to your ArrayLis
        int sizeCheck = sortedList.size();
        if(sizeCheck==1){
            CharFreq pull=sortedList.get(0);    //pulls the charfreq
            char x= pull.getCharacter();        //gets char
            int asciiOne= (int) x;  //makes char into ascii int
            asciiOne ++;    //increments one 
            x= (char) asciiOne;         //back into a char but the next ascii value
            CharFreq one= new CharFreq(x,0);
            sortedList.add(one);  //puts into sorted now there is ["pull", "one"]
            } 
              
        Collections.sort(sortedList);   //sorts the list
       
            return sortedList;
    }

    /**
     * Uses a given sorted arraylist of CharFreq objects to build a huffman coding tree
     * 
     * @param sortedList The arraylist of CharFreq objects to build the tree from
     * @return A TreeNode representing the root of the huffman coding tree
     */
    public static TreeNode makeTree(ArrayList<CharFreq> sortedList) {
        //put arraylist into queue
        TreeNode root= new TreeNode();  //makes treenode root
        Queue<TreeNode> target=new Queue<TreeNode>();
        Queue<TreeNode> source= new Queue<TreeNode>();      //new queue of charFreq type
        int sizeloop = sortedList.size();
        for(int i=0;i<sizeloop;i++){
            CharFreq hold=sortedList.get(i); //takes item out of sorted list
            TreeNode add= new TreeNode();
            add.setData(hold);  //puts charfreq data into the treenode
            //queue is first in first out
            source.enqueue(add);    //enqueues the charfreq
        }   //automatically increasing order because sorted list was sorted
       
       
        //now have source, as per huffman, make target
        while(!source.isEmpty()){   //while queue is not empty
            //find 2 lowest
            TreeNode sourcepeek= source.peek();         //peeks the source
            CharFreq sfreqpeek= sourcepeek.getData();   //gets charfreq access
            TreeNode first= new TreeNode();
            TreeNode second= new TreeNode();
            if(target.isEmpty()){   //nothing in target, then two smallest are first two of source
                first=source.dequeue();     //dequeues smallest
                second=source.dequeue();    //dequeues next smallest
            } //else if(){

           // }
            else{
                TreeNode targetpeek= target.peek();     //peeks the target
                CharFreq tfreqpeek= targetpeek.getData();
                int comp;
                if(sfreqpeek.getProbOccurrence()!=tfreqpeek.getProbOccurrence()){
                    comp= sfreqpeek.compareTo(tfreqpeek); //neg < , zero =, pos >
                }else{
                    comp=0;
                }                
                if(comp<=0){    //when source is < or = to target
                     first= source.dequeue();       //take sourcelowest as first
                    
                    if(!source.isEmpty()){
                        TreeNode nextpeek= source.peek();
                        sfreqpeek= nextpeek.getData();   //gets charfreq access
                        if(sfreqpeek.getProbOccurrence()!=tfreqpeek.getProbOccurrence()){
                            comp= sfreqpeek.compareTo(tfreqpeek); //neg < , zero =, pos >
                        }else{
                            comp=0;
                        }
                        if(comp<=0){
                             second= source.dequeue();
                        }else{
                             second=target.dequeue();
                        }
                    }else{  //if the first smallest was the last thing in source
                          second=target.dequeue();
                    }
                } else{ //when source is > target
                     first= target.dequeue();       //take targetlowest as first
                    if(!target.isEmpty()){
                        TreeNode nextpeek= target.peek();
                        tfreqpeek= nextpeek.getData();   //gets charfreq access
                        if(sfreqpeek.getProbOccurrence()!=tfreqpeek.getProbOccurrence()){
                            comp= sfreqpeek.compareTo(tfreqpeek); //neg < , zero =, pos >
                        }else{
                            comp=0;
                        }
                        if(comp<=0){
                             second= source.dequeue();
                        }else{
                             second=target.dequeue();
                        }
                    }else{
                        second=source.dequeue();    //if target is empty take the second from source
                    }


                    
                    
                }

            }



            //now have first and second smallest
            CharFreq onefreq= first.getData();
            CharFreq twofreq= second.getData();
            double sum= (onefreq.getProbOccurrence()+twofreq.getProbOccurrence());  //adds probabilities
            CharFreq makepar= new CharFreq(null,sum);       //makes char for parent
            TreeNode parent= new TreeNode(makepar,first,second );       //makes treenode parent w/ first and second as its children
           
            target.enqueue(parent); //enqueues the parent + children into the queue


        }

        while(target.size()>1){
            TreeNode first=target.dequeue();      //takes smallest target
            TreeNode second= target.dequeue();      //takes next smallest of target
            CharFreq onefreq= first.getData();
            CharFreq twofreq= second.getData();
            double sum= (onefreq.getProbOccurrence()+twofreq.getProbOccurrence());  //adds probabilities
            CharFreq makepar= new CharFreq(null,sum);       //makes char for parent
            TreeNode parent= new TreeNode(makepar,first,second );       //makes treenode parent w/ first and second as its children
           
            target.enqueue(parent); //enqueues the parent + children into the queue
        }

        //after source is emptied
        root=target.dequeue();
  
        return root; // Delete this line
    }

    /**
     * Uses a given huffman coding tree to create a string array of size 128, where each
     * index in the array contains that ASCII character's bitstring encoding. Characters not
     * present in the huffman coding tree should have their spots in the array left null
     * 
     * @param root The root of the given huffman coding tree
     * @return Array of strings containing only 1's and 0's representing character encodings
     */
    public static String[] makeEncodings(TreeNode root) {
        //takes in the root, make an array for the strings
        String[] array= new String[128];
        //make ptr to traverse tree
        TreeNode ptr= new TreeNode();
        ptr=root;
        String count= new String();
        traverse(ptr, array, count);
        //if it has children it is not a character, no children==character

        return array; // Delete this line
    }
    private static String[] traverse( TreeNode ptr, String[] array, String count){
        if(ptr.getLeft()==null && ptr.getRight()==null){        //you found your char
           
            CharFreq stringCharFreq= ptr.getData();
           char  stringChar= stringCharFreq.getCharacter();
            int asciiNum= (int) stringChar;   //turns into int
            array[asciiNum]= count;
            if (count.length()>0){
                count=count.substring(0, count.length()-1);
            }   //removes last thing added 
            
            return array;
        }else{
       
        traverse(ptr.getLeft(), array, count+'0');
      
        traverse(ptr.getRight(), array, count+'1');
        return array;}
        
    }

    /**
     * Using a given string array of encodings, a given text file, and a file name to encode into,
     * this method makes use of the writeBitString method to write the final encoding of 1's and
     * 0's to the encoded file.
     * 
     * @param encodings The array containing binary string encodings for each ASCII character
     * @param textFile The text file which is to be encoded
     * @param encodedFile The file name into which the text file is to be encoded
     */
    public static void encodeFromArray(String[] encodings, String textFile, String encodedFile) {
        StdIn.setFile(textFile);
        //with input encodings having the 'key' for coding it
        //takes textFile and needs to find textFile in encoding
        //do writeBitString( encodedFile, -- whatever my string is --)
        String myCode= new String();

        //for each char in encodings, need to get the char to ascii int and find it in encodings
        while(StdIn.hasNextChar()){   //while there are more characters to read, while true
            char textChar=StdIn.readChar();     //read each char
            int i=(int) textChar;        //makes char into int for indexing
           myCode =myCode+encodings[i];    //current string + the i's character, adds onto existing
        }
        writeBitString(encodedFile, myCode);
    }
    
    /**
     * Using a given encoded file name and a huffman coding tree, this method makes use of the 
     * readBitString method to convert the file into a bit string, then decodes the bit string
     * using the tree, and writes it to a file.
     * 
     * @param encodedFile The file which contains the encoded text we want to decode
     * @param root The root of your Huffman Coding tree
     * @param decodedFile The file which you want to decode into
     */
    public static void decode(String encodedFile, TreeNode root, String decodedFile) {
        StdOut.setFile(decodedFile);
        String given= new String();
        given= readBitString( encodedFile);     //given recevies the 0/1 string
        TreeNode ptr= new TreeNode();
        ptr=root;   //pointer to follow the route down the tree
        int index=0;
       while(index<given.length()){     //while there is still items unchecked in given
            while(ptr.getLeft()!=null && ptr.getRight()!=null){
                char see=given.charAt(index);
                if(see=='0'){
                    ptr=ptr.getLeft();  //ptr moves to left child
                } else if(see=='1'){
                    ptr=ptr.getRight(); //ptr moves to  right child
                }else{
                    return;
                }
                index=index+1;  //moves index over to next char
            }
           //when left and right are null, no children
           //found a char, need to get that info now
            CharFreq found= ptr.getData();
            char gotIt= found.getCharacter();
            StdOut.print(gotIt);
           //reset ptr at root
           ptr=root;
        }

        //it actually worked  OoO
    
        

    }
}
