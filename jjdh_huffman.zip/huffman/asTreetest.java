public static ArrayList<CharFreq> makeSortedList(String filename) {
    StdIn.setFile(filename);
    /* Your code goes here */

    //Base:: 
    //The Huffman Coding algorithm does not work when there is only 1 distinct character. 
    //For this specific case, you must add a different character with probOcc 0 to your ArrayLis

    while (StdIn.hasNextChar()) {
        char c = StdIn.readChar();
        StdOut.print(c);
    }

}

public static void main (String[] args){
makeSortedList(input1.txt);

}

}